package com.exemplo.jarvis

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Cyan = Color(0xFF3FE0FF)
private val CyanD = Color(0xFF1A9DC2)
private val Bg = Color(0xFF020B14)
private val Panel = Color(0xFF06202F)
private val Txt = Color(0xFFCDF3FF)
private val Gold = Color(0xFFFFB347)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, onPrimary = Bg, background = Bg, surface = Panel,
                    onSurface = Txt, onBackground = Txt
                )
            ) { Surface(Modifier.fillMaxSize(), color = Bg) { JarvisApp() } }
        }
    }
}

/** Reator de arco: 10 bobinas girando, anel tracejado, anel interno contrarrotativo e núcleo pulsante. */
@Composable
fun Reactor(busy: Boolean, speaking: Boolean, diameter: Dp = 84.dp, modifier: Modifier = Modifier) {
    val active = busy || speaking
    val tr = rememberInfiniteTransition(label = "r")
    val ang by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 2200 else 9000, easing = LinearEasing)), label = "a")
    val rev by tr.animateFloat(360f, 0f, infiniteRepeatable(tween(if (active) 3000 else 14000, easing = LinearEasing)), label = "b")
    val pulse by tr.animateFloat(0.55f, 1f, infiniteRepeatable(tween(if (active) 600 else 2600), RepeatMode.Reverse), label = "p")
    Canvas(modifier.size(diameter)) {
        val c = center
        val r = size.minDimension / 2
        // brilho difuso ao redor do reator
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.35f * pulse), Color.Transparent), c, r), r, c)
        val dash = 4.dp.toPx()
        drawCircle(
            Cyan.copy(alpha = 0.5f), r - 1.dp.toPx(), c,
            style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(dash, dash)))
        )
        // 10 bobinas do reator
        rotate(ang, c) {
            val rr = r * 0.72f
            val tl = Offset(c.x - rr, c.y - rr)
            val sz = Size(rr * 2, rr * 2)
            for (i in 0 until 10) {
                drawArc(CyanD, i * 36f + 4f, 24f, false, tl, sz, style = Stroke(4.dp.toPx()))
            }
        }
        // anel interno girando ao contrário
        rotate(rev, c) {
            val rr = r * 0.5f
            val tl = Offset(c.x - rr, c.y - rr)
            val sz = Size(rr * 2, rr * 2)
            drawArc(Cyan, 10f, 100f, false, tl, sz, style = Stroke(2.dp.toPx()))
            drawArc(Cyan, 190f, 100f, false, tl, sz, style = Stroke(2.dp.toPx()))
        }
        drawCircle(Cyan, r * 0.3f, c, style = Stroke(2.dp.toPx()))
        drawCircle(Color.White.copy(alpha = pulse), r * 0.16f * (0.8f + 0.2f * pulse), c)
    }
}

/** Fundo estilo HUD: grade discreta e círculos concêntricos. */
private fun Modifier.hudBackground(): Modifier = this.drawBehind {
    val line = Cyan.copy(alpha = 0.05f)
    val step = 36.dp.toPx()
    var x = 0f
    while (x < size.width) {
        drawLine(line, Offset(x, 0f), Offset(x, size.height), 1f)
        x += step
    }
    var y = 0f
    while (y < size.height) {
        drawLine(line, Offset(0f, y), Offset(size.width, y), 1f)
        y += step
    }
    val c = Offset(size.width / 2, size.height * 0.5f)
    drawCircle(Cyan.copy(alpha = 0.05f), size.width * 0.75f, c, style = Stroke(1.dp.toPx()))
    drawCircle(Cyan.copy(alpha = 0.04f), size.width * 0.5f, c, style = Stroke(1.dp.toPx()))
}

/** Sequência de inicialização, como a abertura dos sistemas no laboratório. */
@Composable
fun BootSequence(onDone: () -> Unit) {
    val lines = listOf(
        "INICIALIZANDO PROTOCOLOS J.A.R.V.I.S.",
        "REATOR DE ARCO ............ ESTÁVEL",
        "NÚCLEO DE LINGUAGEM ....... ONLINE",
        "SÍNTESE DE VOZ ............ ONLINE",
        "RECONHECIMENTO DE VOZ ..... ONLINE",
        "BEM-VINDO DE VOLTA, SENHOR."
    )
    var shown by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        for (i in 1..lines.size) {
            delay(420)
            shown = i
        }
        delay(700)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Bg).hudBackground(), contentAlignment = Alignment.Center) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Reactor(busy = true, speaking = false, diameter = 140.dp)
            Spacer(Modifier.height(28.dp))
            lines.take(shown).forEachIndexed { i, l ->
                Text(
                    l, color = if (i == lines.lastIndex) Cyan else CyanD,
                    fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 1.sp,
                    fontWeight = if (i == lines.lastIndex) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

/** Balão de mensagem; as respostas novas do Jarvis aparecem digitadas, caractere a caractere. */
@Composable
fun Bubble(m: Msg, animate: Boolean, onRevealed: () -> Unit) {
    var n by remember { mutableStateOf(if (animate) 0 else m.text.length) }
    LaunchedEffect(animate) {
        if (animate) {
            while (n < m.text.length) {
                delay(18)
                n++
            }
            onRevealed()
        }
    }
    val shape = RoundedCornerShape(4.dp)
    val accent = if (m.err) Gold else if (m.mine) Cyan else CyanD
    val label = if (m.err) "AVISO" else if (m.mine) "VOCÊ" else "J.A.R.V.I.S."
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier.widthIn(max = 320.dp)
                .background(if (m.mine) Color(0xFF0B3A57) else Panel.copy(alpha = 0.85f), shape)
                .border(1.dp, accent.copy(alpha = 0.55f), shape)
                .padding(10.dp)
        ) {
            Text(label, color = accent, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            SelectionContainer {
                Text(m.text.take(n), color = if (m.err) Gold else Txt)
            }
        }
    }
}

@Composable
fun JarvisApp(vm: JarvisViewModel = viewModel()) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var input by rememberSaveable { mutableStateOf("") }
    var newTask by rememberSaveable { mutableStateOf("") }
    var speakOn by rememberSaveable { mutableStateOf(true) }
    var booted by rememberSaveable { mutableStateOf(false) }
    var revealedUpTo by rememberSaveable { mutableStateOf(vm.msgs.size) }
    val speakNow by rememberUpdatedState(speakOn)
    val listState = rememberLazyListState()
    val tts = remember { mutableStateOf<TextToSpeech?>(null) }
    var speaking by remember { mutableStateOf(false) }

    var now by remember { mutableStateOf(Date()) }
    val clock = remember { SimpleDateFormat("HH:mm:ss", Locale.forLanguageTag("pt-BR")) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }

    // Voz grave e pausada, no tom calmo do Jarvis.
    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.setLanguage(Locale.forLanguageTag("pt-BR"))
                engine?.setPitch(0.8f)
                engine?.setSpeechRate(0.95f)
            }
        }
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true }
            override fun onDone(utteranceId: String?) { speaking = false }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { speaking = false }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { speaking = false }
        })
        tts.value = engine
        onDispose {
            engine?.shutdown()
            tts.value = null
        }
    }

    // Fala cada nova resposta uma única vez (não repete ao girar a tela).
    LaunchedEffect(Unit) {
        vm.speech.collect { if (speakNow) tts.value?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    }

    // Se a conversa foi limpa, as próximas respostas voltam a ser digitadas.
    LaunchedEffect(vm.msgs.size) {
        if (vm.msgs.size < revealedUpTo) revealedUpTo = vm.msgs.size
    }

    // Rola até a última mensagem, inclusive ao voltar para a aba de conversa.
    LaunchedEffect(vm.msgs.size, tab, booted) {
        if (tab == 0 && vm.msgs.isNotEmpty()) listState.animateScrollToItem(vm.msgs.lastIndex)
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
                if (!vm.send(it) && vm.busy) vm.notify("Ainda estou processando o pedido anterior, senhor.")
            }
        }
    }

    val startListening: () -> Unit = {
        tts.value?.stop()
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Pois não, senhor")
            )
        } catch (e: ActivityNotFoundException) {
            vm.notify("Este aparelho não tem reconhecimento de voz instalado.")
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().hudBackground().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Toque no reator para falar com o Jarvis.
                Reactor(
                    vm.busy, speaking,
                    modifier = Modifier.clickable { startListening() }
                        .semantics { contentDescription = "Reator. Toque para falar com o Jarvis" }
                )
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("J.A.R.V.I.S.", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text(
                        when {
                            vm.busy -> "Processando…"
                            speaking -> "Respondendo…"
                            else -> "Sistemas online"
                        },
                        color = CyanD, fontSize = 14.sp
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(clock.format(now), color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 13.sp, letterSpacing = 1.sp)
                    TextButton({ vm.showKey = true }) { Text("Chave") }
                }
            }
            TabRow(tab, containerColor = Color.Transparent, contentColor = Cyan) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Conversa") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Tarefas (${vm.tasks.count { !it.done }})") })
            }
            if (tab == 0) {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), state = listState,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(vm.msgs) { i, m ->
                        Bubble(m, animate = !m.mine && !m.err && i >= revealedUpTo) {
                            revealedUpTo = maxOf(revealedUpTo, i + 1)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        input, { input = it }, Modifier.weight(1f), singleLine = true,
                        placeholder = { Text("Fale ou digite, senhor…") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { if (vm.send(input)) input = "" })
                    )
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton({ startListening() }) { Text("Voz") }
                    Spacer(Modifier.width(6.dp))
                    Button({ if (vm.send(input)) input = "" }, enabled = !vm.busy && input.isNotBlank()) { Text("Enviar") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton({
                        speakOn = !speakOn
                        if (!speakOn) tts.value?.stop()
                    }) {
                        Text("Respostas faladas: ${if (speakOn) "ligadas" else "desligadas"}")
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton({
                        tts.value?.stop()
                        vm.clearChat()
                    }) { Text("Limpar") }
                }
            } else {
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
                    if (vm.tasks.isEmpty()) {
                        item { Text("Nenhuma tarefa, senhor. Adicione abaixo ou peça a mim.", color = CyanD) }
                    }
                    items(vm.tasks, key = { it.id }) { t ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(t.done, { vm.toggle(t.id, it) })
                            Text(
                                t.text, Modifier.weight(1f), color = if (t.done) CyanD else Txt,
                                textDecoration = if (t.done) TextDecoration.LineThrough else null
                            )
                            TextButton(
                                { vm.remove(t.id) },
                                Modifier.semantics { contentDescription = "Remover tarefa ${t.text}" }
                            ) { Text("×") }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        newTask, { newTask = it }, Modifier.weight(1f), singleLine = true,
                        placeholder = { Text("Nova tarefa…") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { if (vm.addTask(newTask)) newTask = "" })
                    )
                    Spacer(Modifier.width(6.dp))
                    Button({ if (vm.addTask(newTask)) newTask = "" }) { Text("Adicionar") }
                }
            }
        }

        if (!booted) {
            BootSequence {
                booted = true
                if (speakNow) tts.value?.speak("Bem-vindo de volta, senhor. Todos os sistemas estão operando normalmente.", TextToSpeech.QUEUE_FLUSH, null, "jarvis")
            }
        }
    }

    if (vm.showKey) {
        var draft by remember { mutableStateOf(vm.apiKey) }
        AlertDialog(
            onDismissRequest = { vm.showKey = false },
            title = { Text("Chave da API Anthropic") },
            text = {
                Column {
                    Text("Fica salva só neste aparelho, sem backup na nuvem. Crie a sua em console.anthropic.com.", fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        draft, { draft = it }, singleLine = true,
                        placeholder = { Text("sk-ant-…") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                }
            },
            confirmButton = {
                TextButton({
                    vm.saveKey(draft)
                    vm.showKey = false
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton({ vm.showKey = false }) { Text("Cancelar") } }
        )
    }
}
