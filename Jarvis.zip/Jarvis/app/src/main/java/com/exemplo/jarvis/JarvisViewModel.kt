package com.exemplo.jarvis

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Calendar

/**
 * Guarda o estado fora da tela: girar o aparelho não apaga a conversa
 * nem cancela uma resposta que ainda está a caminho.
 */
class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    val tasks = mutableStateListOf<Task>().apply { addAll(store.loadTasks()) }
    val msgs = mutableStateListOf<Msg>().apply {
        addAll(store.loadMsgs().ifEmpty { listOf(welcome()) })
    }

    var apiKey by mutableStateOf(store.apiKey)
        private set
    var busy by mutableStateOf(false)
        private set
    var showKey by mutableStateOf(false)

    private val _speech = MutableSharedFlow<String>(extraBufferCapacity = 1)
    /** Respostas a serem faladas pela tela (TTS). */
    val speech: SharedFlow<String> = _speech.asSharedFlow()

    private fun welcome() = Msg(false, "${greeting()}, senhor. Todos os sistemas estão operando normalmente. Em que posso ser útil?")

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h < 5 -> "Boa noite"
            h < 12 -> "Bom dia"
            h < 18 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    private fun persist() = store.saveTasks(tasks.toList())

    private fun addMsg(m: Msg) {
        msgs.add(m)
        store.saveMsgs(msgs.toList())
    }

    /** Aviso local do app (não vai para o modelo nem é salvo). */
    fun notify(text: String) {
        msgs.add(Msg(false, text, err = true))
    }

    fun clearChat() {
        msgs.clear()
        msgs.add(welcome())
        store.saveMsgs(msgs.toList())
    }

    fun saveKey(k: String) {
        apiKey = k.trim()
        store.apiKey = apiKey
    }

    fun addTask(text: String): Boolean {
        val v = text.trim()
        if (v.isEmpty()) return false
        tasks.add(Task(v.take(MAX_TASK_LEN), false))
        persist()
        return true
    }

    fun toggle(id: String, done: Boolean) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i >= 0) {
            tasks[i] = tasks[i].copy(done = done)
            persist()
        }
    }

    fun remove(id: String) {
        tasks.removeAll { it.id == id }
        persist()
    }

    /** Devolve true se a mensagem foi aceita (a tela então limpa o campo). */
    fun send(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || busy) return false
        if (apiKey.isBlank()) {
            showKey = true
            return false
        }
        addMsg(Msg(true, t))
        busy = true
        val seen = tasks.toList() // o que o modelo vai enxergar
        val hist = msgs.toList().filter { !it.err }.takeLast(12).dropWhile { !it.mine }
        viewModelScope.launch {
            try {
                val raw = ClaudeApi.chat(apiKey, ClaudeApi.systemPrompt(seen), hist)
                val (reply, actions, json) = parseReply(raw)
                if (actions != null) {
                    val updated = applyActions(tasks.toList(), seen, actions)
                    tasks.clear()
                    tasks.addAll(updated)
                    persist()
                }
                addMsg(Msg(false, reply, raw = json))
                _speech.tryEmit(reply)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                msgs.add(Msg(false, friendly(e), err = true))
            } finally {
                busy = false
            }
        }
        return true
    }

    /** Se o modelo não devolver o JSON esperado, usa o texto puro em vez de dar erro. */
    private data class Parsed(val reply: String, val actions: JSONArray?, val json: String?)

    private fun parseReply(raw: String): Parsed {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s in 0 until e) {
            try {
                val j = JSONObject(raw.substring(s, e + 1))
                if (j.has("reply")) {
                    return Parsed(j.optString("reply").ifBlank { "Feito, senhor." }, j.optJSONArray("actions"), j.toString())
                }
            } catch (ex: Exception) {
                // cai para o texto puro abaixo
            }
        }
        return Parsed(raw.trim().ifEmpty { "Sem resposta, senhor." }, null, null)
    }

    private fun friendly(e: Exception): String = when {
        e is ApiException && (e.code == 401 || e.code == 403) ->
            "Chave da API inválida ou sem permissão. Toque em “Chave” para conferir."
        e is ApiException && e.code == 429 -> "Limite de uso atingido. Tente de novo em instantes."
        e is ApiException && e.code >= 500 -> "O serviço da Anthropic está indisponível ou sobrecarregado. Tente de novo."
        e is ApiException -> "Erro ${e.code}" + (e.message?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "")
        e is IOException -> "Sem conexão com a internet."
        else -> "Falha inesperada (${e.message})."
    }
}
