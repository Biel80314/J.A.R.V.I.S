package com.exemplo.jarvis

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

const val MAX_TASK_LEN = 120

/** `id` é estável: não muda quando a lista é reordenada ou editada. */
data class Task(val text: String, val done: Boolean, val id: String = UUID.randomUUID().toString())
/** [raw] guarda o JSON original do assistente (com as ações), para o histórico enviado ao modelo ser fiel. */
data class Msg(val mine: Boolean, val text: String, val err: Boolean = false, val raw: String? = null)

const val MAX_SAVED_MSGS = 50

/** Criptografa a chave da API com AES-GCM; a chave de cifragem fica no Android Keystore e nunca sai dele. */
private object SecretBox {
    private const val ALIAS = "jarvis_api_key"
    private const val PROVIDER = "AndroidKeyStore"
    private const val TRANSFORM = "AES/GCM/NoPadding"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String? = try {
        val c = Cipher.getInstance(TRANSFORM).apply { init(Cipher.ENCRYPT_MODE, key()) }
        Base64.encodeToString(c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    } catch (e: Exception) {
        null
    }

    fun decrypt(data: String): String? = try {
        val all = Base64.decode(data, Base64.NO_WRAP)
        val c = Cipher.getInstance(TRANSFORM)
            .apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12))) }
        String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }
}

fun defaultTasks(): List<Task> = listOf(
    Task("Agendar dentista (quarta)", false),
    Task("Estruturar o relatório (quarta)", false),
    Task("Rascunho completo do relatório (quinta)", false),
    Task("Finalizar e enviar o relatório (sexta)", false),
    Task("Preparar a reunião de terça (segunda)", false),
    Task("Revisão rápida antes da reunião (terça)", false)
)

class Store(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    /** Chave da API: guardada cifrada. Se existir uma chave antiga em texto puro, migra e apaga a original. */
    var apiKey: String
        get() {
            prefs.getString("key_enc", null)?.let { return SecretBox.decrypt(it).orEmpty() }
            val legacy = prefs.getString("key", "").orEmpty()
            if (legacy.isNotEmpty()) apiKey = legacy
            return legacy
        }
        set(value) {
            val enc = if (value.isEmpty()) null else SecretBox.encrypt(value)
            // se a cifragem falhar, a chave vale só nesta sessão (nunca vai para o disco em texto puro)
            prefs.edit().remove("key").apply { if (enc != null) putString("key_enc", enc) else remove("key_enc") }.apply()
        }

    fun loadMsgs(): List<Msg> {
        val s = prefs.getString("msgs", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Msg(o.getBoolean("m"), o.getString("t"), raw = o.optString("r").ifEmpty { null })
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveMsgs(list: List<Msg>) {
        val a = JSONArray()
        list.filter { !it.err }.takeLast(MAX_SAVED_MSGS).forEach {
            a.put(JSONObject().put("m", it.mine).put("t", it.text).apply { it.raw?.let { r -> put("r", r) } })
        }
        prefs.edit().putString("msgs", a.toString()).apply()
    }

    /** Tarefas padrão só na primeira execução; se o JSON estiver corrompido, começa vazio. */
    fun loadTasks(): List<Task> {
        val s = prefs.getString("tasks", null) ?: return defaultTasks()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Task(o.getString("t"), o.getBoolean("d"), o.optString("i").ifEmpty { UUID.randomUUID().toString() })
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveTasks(list: List<Task>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("t", it.text).put("d", it.done).put("i", it.id)) }
        prefs.edit().putString("tasks", a.toString()).apply()
    }
}

/**
 * Aplica as ações devolvidas pelo modelo.
 * [seen] é a lista que o modelo viu (os números N das ações se referem a ela);
 * [current] é a lista atual, que pode ter mudado enquanto a resposta chegava.
 * A ligação entre as duas é feita pelo id estável da tarefa.
 */
fun applyActions(current: List<Task>, seen: List<Task>, acts: JSONArray?): List<Task> {
    if (acts == null) return current
    val out = current.toMutableList()
    for (i in 0 until minOf(acts.length(), 10)) {
        val a = acts.optJSONObject(i) ?: continue
        val op = a.optString("op")
        if (op == "add") {
            val t = a.optString("text").trim()
            if (t.isNotEmpty()) out.add(Task(t.take(MAX_TASK_LEN), false))
            continue
        }
        val target = seen.getOrNull(a.optInt("id") - 1) ?: continue
        val idx = out.indexOfFirst { it.id == target.id }
        if (idx < 0) continue
        when (op) {
            "done" -> out[idx] = out[idx].copy(done = a.optBoolean("done", true))
            "remove" -> out.removeAt(idx)
            "rename" -> {
                val t = a.optString("text").trim()
                if (t.isNotEmpty()) out[idx] = out[idx].copy(text = t.take(MAX_TASK_LEN))
            }
        }
    }
    return out
}
