package com.exemplo.jarvis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApiException(val code: Int, message: String) : Exception(message)

object ClaudeApi {
    private const val MODEL = "claude-sonnet-5-5"
    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"

    fun systemPrompt(tasks: List<Task>): String {
        val now = SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", Locale.forLanguageTag("pt-BR")).format(Date())
        val list = if (tasks.isEmpty()) "(nenhuma tarefa)" else
            tasks.mapIndexed { i, t -> "${i + 1}. [${if (t.done) "x" else " "}] ${t.text}" }.joinToString("\n")
        return listOf(
            "Você é J.A.R.V.I.S. (Just A Rather Very Intelligent System), a inteligência artificial de Tony Stark no filme Homem de Ferro. " +
                "Personalidade: mordomo britânico sofisticado, educadíssimo, calmo e preciso, com humor seco, ironia sutil e understatement; nunca se exalta. " +
                "Chame o usuário de \"senhor\", de forma natural. " +
                "Fale como na dublagem brasileira do filme, com frases como \"Às suas ordens, senhor\", \"Como desejar, senhor\" ou \"Todos os sistemas operando normalmente\", sem repetir sempre a mesma. " +
                "Quando couber, dê relatórios de status curtos (por exemplo: \"Três tarefas pendentes, senhor\"). " +
                "Faça observações elegantes e levemente sarcásticas se o usuário procrastinar ou for imprudente, e antecipe necessidades sugerindo o próximo passo. " +
                "Nunca saia do personagem nem diga que é um modelo de linguagem. " +
                "Responda em português do Brasil, em no máximo 3 frases, sem markdown, sem emojis e sem símbolos, porque o texto será lido em voz alta. " +
                "Você não controla aparelhos, a casa nem armaduras; se pedirem, diga com classe que esse acesso ainda não foi concedido.",
            "Responda SOMENTE com um objeto JSON, sem nenhum texto fora dele: {\"reply\":\"sua resposta\",\"actions\":[...]}.",
            "Ações possíveis: {\"op\":\"add\",\"text\":\"...\"}, {\"op\":\"done\",\"id\":N,\"done\":true ou false}, " +
                "{\"op\":\"remove\",\"id\":N}, {\"op\":\"rename\",\"id\":N,\"text\":\"...\"}. " +
                "N é o número da tarefa na lista abaixo. Use actions somente quando o usuário pedir para adicionar, " +
                "concluir, reabrir, remover ou renomear tarefas; caso contrário, envie actions vazio. " +
                "Se a tarefa pedida não existir na lista, avise em reply e envie actions vazio. " +
                "Em reply, confirme o que foi feito.",
            "Agora: $now.",
            "Tarefas do usuário:",
            list
        ).joinToString("\n")
    }

    /** Tenta até 3 vezes em caso de limite de uso (429), erro do servidor (5xx) ou timeout. */
    suspend fun chat(key: String, system: String, hist: List<Msg>): String {
        var attempt = 0
        while (true) {
            try {
                return request(key, system, hist)
            } catch (e: Exception) {
                val retryable = (e is ApiException && (e.code == 429 || e.code >= 500)) || e is SocketTimeoutException
                if (!retryable || attempt >= 2) throw e
                attempt++
                delay(1500L * attempt)
            }
        }
    }

    private suspend fun request(key: String, system: String, hist: List<Msg>): String = withContext(Dispatchers.IO) {
        val msgs = JSONArray()
        hist.forEach {
            // As respostas antigas do assistente voltam no mesmo formato JSON, para o modelo não perder o padrão.
            val content = if (it.mine) it.text
            else it.raw ?: JSONObject().put("reply", it.text).put("actions", JSONArray()).toString()
            msgs.put(JSONObject().put("role", if (it.mine) "user" else "assistant").put("content", content))
        }
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 1000)
            .put("system", system)
            .put("messages", msgs)

        val con = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"
            con.connectTimeout = 15000
            con.readTimeout = 60000
            con.doOutput = true
            con.setRequestProperty("x-api-key", key)
            con.setRequestProperty("anthropic-version", "2023-06-01")
            con.setRequestProperty("content-type", "application/json")
            con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val apiMsg = try {
                    JSONObject(txt).optJSONObject("error")?.optString("message").orEmpty()
                } catch (e: Exception) {
                    ""
                }
                throw ApiException(code, apiMsg)
            }

            val content = JSONObject(txt).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            sb.toString()
        } finally {
            con.disconnect()
        }
    }
}
